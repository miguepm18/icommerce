package com.ada.repository;

import com.ada.entity.Receta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecetaRepository extends JpaRepository<Receta,Integer>{
    
    
    
    
    
}

